﻿using System;
using System.Collections;

namespace StudentsManagement
{
    delegate void MyDelegate(string str);
    delegate string MyStringDelegate();
    delegate int intDelegates();
    class Program
    {
        static void Main(string[] args)
        {

            Classroom classroom = new Classroom(new string[3] { "math", "english", "physics" });
            Analyzer analyzer = new Analyzer(classroom);
            System system = new System(classroom, analyzer);
            system.run();

        }
    }
}
